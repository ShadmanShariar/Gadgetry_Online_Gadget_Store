<!DOCTYPE html>
<html>
<head>
<title> Login System </title>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<h1> User Login </h1>
     <form action="login_action.php" method="post">
		<table align="center">
			<tr>
			  <td>
				<input type="text" name="lastName" placeholder="User Name"/>
			  </td>
			</tr>
			
			<tr>
			  <td>
				<input type="password" name="password" placeholder="Password"/>
			  </td>
			</tr>
			
		    <tr>
			  <td>
				<input type="submit" name="submit" value="LOGIN"/>
			  </td>
			</tr>
		</table>
		</form>
		
</body>
</html>